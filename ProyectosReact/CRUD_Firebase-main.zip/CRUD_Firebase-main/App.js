import Navigation from "./src/Navigation";

export default function App() {
  return (
    <Navigation />
  );
}
